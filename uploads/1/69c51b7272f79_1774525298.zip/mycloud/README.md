# MyCloud — Panduan Instalasi VPS

## Struktur Proyek
```
mycloud/
├── backend/
│   ├── server.js          ← Entry point
│   ├── db.js              ← MySQL connection
│   ├── middleware/auth.js ← JWT middleware
│   ├── routes/
│   │   ├── auth.js        ← Login, register, dashboard stats
│   │   ├── tasks.js       ← CRUD tasks + filter
│   │   ├── links.js       ← CRUD links + click tracking
│   │   ├── files.js       ← Upload, download, preview, delete
│   │   ├── admin.js       ← User management
│   │   └── notify.js      ← Push notifications + cron job
│   └── uploads/           ← Folder penyimpanan file fisik
│
├── frontend/
│   ├── index.html         ← Login page
│   ├── sidebar.html       ← Shared sidebar component
│   ├── css/style.css      ← Neon dark theme
│   ├── js/
│   │   ├── app.js         ← API client + helpers
│   │   └── sw.js          ← Service Worker (push notif)
│   └── pages/
│       ├── dashboard.html ← Dashboard + Chart.js
│       ├── tasks.html     ← Task manager + filter
│       ├── links.html     ← Link manager (linktree style)
│       ├── files.html     ← File manager (drag & drop)
│       ├── admin.html     ← Admin panel
│       └── profile.html   ← Profil + notifikasi settings
│
├── database.sql           ← Schema MySQL lengkap
├── package.json
└── .env.example           ← Template konfigurasi
```

---

## 1. Persiapan VPS

```bash
# Update sistem
sudo apt update && sudo apt upgrade -y

# Install Node.js 20 LTS
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# Install MySQL
sudo apt install -y mysql-server
sudo mysql_secure_installation

# Install PM2 (process manager)
sudo npm install -g pm2

# Install Nginx
sudo apt install -y nginx
```

---

## 2. Setup MySQL

```bash
# Login MySQL
sudo mysql -u root -p

# Buat user baru (lebih aman dari root)
CREATE USER 'mycloud_user'@'localhost' IDENTIFIED BY 'PASSWORD_KUAT_DISINI';
GRANT ALL PRIVILEGES ON mycloud_db.* TO 'mycloud_user'@'localhost';
FLUSH PRIVILEGES;
EXIT;

# Import schema
mysql -u mycloud_user -p < database.sql
```

---

## 3. Install & Konfigurasi App

```bash
# Clone / upload project ke VPS
cd /var/www
git clone https://github.com/yourusername/mycloud.git
# ATAU upload via SCP/FTP

cd mycloud

# Install dependencies
npm install

# Buat file .env dari template
cp .env.example .env
nano .env
```

### Isi file `.env`:
```env
PORT=3000
NODE_ENV=production
BASE_URL=https://cloud.yourdomain.com

DB_HOST=localhost
DB_PORT=3306
DB_USER=mycloud_user
DB_PASSWORD=PASSWORD_KUAT_DISINI
DB_NAME=mycloud_db

JWT_SECRET=GANTI_DENGAN_STRING_ACAK_PANJANG_MIN_64_KARAKTER

VAPID_PUBLIC_KEY=   ← generate di bawah
VAPID_PRIVATE_KEY=  ← generate di bawah
VAPID_EMAIL=mailto:admin@yourdomain.com
```

### Generate VAPID Keys untuk Push Notifikasi:
```bash
node -e "const wp=require('web-push'); const k=wp.generateVAPIDKeys(); console.log('PUBLIC:', k.publicKey); console.log('PRIVATE:', k.privateKey);"
```
Copy output ke `.env`

---

## 4. Buat Folder Uploads

```bash
mkdir -p /var/www/mycloud/backend/uploads
chmod 755 /var/www/mycloud/backend/uploads
```

---

## 5. Jalankan dengan PM2

```bash
cd /var/www/mycloud

# Start app
pm2 start backend/server.js --name mycloud

# Auto-start saat VPS reboot
pm2 startup
pm2 save

# Cek status
pm2 status
pm2 logs mycloud
```

---

## 6. Konfigurasi Nginx (Reverse Proxy)

```bash
sudo nano /etc/nginx/sites-available/mycloud
```

Isi:
```nginx
server {
    listen 80;
    server_name cloud.yourdomain.com;

    # Max upload size
    client_max_body_size 105M;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        proxy_read_timeout 300s;
        proxy_send_timeout 300s;
    }
}
```

```bash
# Aktifkan config
sudo ln -s /etc/nginx/sites-available/mycloud /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

---

## 7. SSL dengan Let's Encrypt

```bash
sudo apt install certbot python3-certbot-nginx -y
sudo certbot --nginx -d cloud.yourdomain.com
```

---

## 8. Login Pertama

Buka browser: `https://cloud.yourdomain.com`

```
Email: admin@mycloud.local
Password: Admin@123456
```

**⚠️ SEGERA ganti password setelah login pertama!**
Pergi ke menu **Profil** → **Ganti Password**

---

## 9. Maintenance

```bash
# Restart app
pm2 restart mycloud

# Lihat logs
pm2 logs mycloud --lines 100

# Backup database
mysqldump -u mycloud_user -p mycloud_db > backup_$(date +%Y%m%d).sql

# Update app
cd /var/www/mycloud
git pull
npm install
pm2 restart mycloud
```

---

## Push Notifications — Catatan Penting

- **Android Chrome/Firefox**: Langsung berfungsi setelah subscribe
- **iOS Safari**: Membutuhkan iOS 16.4+ dan tambahkan ke Home Screen (Add to Home Screen)
- **Desktop**: Semua browser modern mendukung

Untuk mengaktifkan notifikasi, pergi ke **Profil** → aktifkan toggle **Push Notification**

---

## Firewall (Opsional tapi Disarankan)

```bash
sudo ufw allow OpenSSH
sudo ufw allow 'Nginx Full'
sudo ufw enable
```

---

## Troubleshooting

| Masalah | Solusi |
|---------|--------|
| Port 3000 tidak bisa diakses | Pastikan Nginx running: `sudo systemctl status nginx` |
| MySQL connection error | Cek .env DB credentials, cek MySQL running: `sudo systemctl status mysql` |
| Upload gagal | Cek folder permissions: `chmod 755 backend/uploads` |
| Push notif tidak sampai | Pastikan VAPID keys sudah di-generate dan diisi di .env |
| PM2 tidak start | Cek `pm2 logs mycloud` untuk error detail |
