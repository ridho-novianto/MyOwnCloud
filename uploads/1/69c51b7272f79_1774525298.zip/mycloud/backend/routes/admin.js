const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const db = require('../db');
const { authMiddleware, adminMiddleware } = require('../middleware/auth');

// All admin routes require auth + admin role
router.use(authMiddleware, adminMiddleware);

// GET /api/admin/users
router.get('/users', async (req, res) => {
    try {
        const [users] = await db.execute(`
            SELECT u.id, u.name, u.email, u.role, u.is_active, u.storage_used, u.storage_limit, 
                   u.last_login, u.created_at,
                   COUNT(DISTINCT t.id) as task_count,
                   COUNT(DISTINCT l.id) as link_count,
                   COUNT(DISTINCT f.id) as file_count
            FROM users u
            LEFT JOIN tasks t ON u.id = t.user_id
            LEFT JOIN links l ON u.id = l.user_id
            LEFT JOIN files f ON u.id = f.user_id
            GROUP BY u.id
            ORDER BY u.created_at DESC
        `);
        res.json({ success: true, users });
    } catch (err) {
        console.error('Admin users error:', err);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// PUT /api/admin/users/:id
router.put('/users/:id', async (req, res) => {
    try {
        const { name, email, role, is_active, storage_limit, password } = req.body;
        const updates = [];
        const values = [];

        if (name) { updates.push('name = ?'); values.push(name); }
        if (email) { updates.push('email = ?'); values.push(email); }
        if (role) { updates.push('role = ?'); values.push(role); }
        if (is_active !== undefined) { updates.push('is_active = ?'); values.push(is_active ? 1 : 0); }
        if (storage_limit) { updates.push('storage_limit = ?'); values.push(storage_limit); }
        if (password) {
            const hashed = await bcrypt.hash(password, 12);
            updates.push('password = ?');
            values.push(hashed);
        }

        if (!updates.length) return res.status(400).json({ success: false, message: 'Tidak ada yang diubah' });

        values.push(req.params.id);
        await db.execute(`UPDATE users SET ${updates.join(', ')} WHERE id = ?`, values);

        res.json({ success: true, message: 'User berhasil diupdate' });
    } catch (err) {
        console.error('Admin update user error:', err);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// DELETE /api/admin/users/:id
router.delete('/users/:id', async (req, res) => {
    try {
        if (req.params.id == req.user.id) {
            return res.status(400).json({ success: false, message: 'Tidak bisa menghapus diri sendiri' });
        }
        await db.execute('DELETE FROM users WHERE id = ?', [req.params.id]);
        res.json({ success: true, message: 'User dihapus' });
    } catch (err) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// GET /api/admin/stats
router.get('/stats', async (req, res) => {
    try {
        const [[userStats]] = await db.execute(`
            SELECT COUNT(*) as total, SUM(is_active=1) as active, 
                   SUM(role='admin') as admins, SUM(storage_used) as total_storage
            FROM users
        `);
        const [[taskStats]] = await db.execute(`SELECT COUNT(*) as total, SUM(status='done') as done FROM tasks`);
        const [[fileStats]] = await db.execute(`SELECT COUNT(*) as total, SUM(file_size) as total_size FROM files`);
        const [[linkStats]] = await db.execute(`SELECT COUNT(*) as total FROM links`);

        const [recentActivity] = await db.execute(`
            SELECT al.*, u.name FROM activity_logs al
            JOIN users u ON al.user_id = u.id
            ORDER BY al.created_at DESC LIMIT 20
        `);

        // New users per day last 7 days
        const [userGrowth] = await db.execute(`
            SELECT DATE(created_at) as date, COUNT(*) as count
            FROM users WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
            GROUP BY DATE(created_at)
        `);

        res.json({
            success: true,
            stats: { users: userStats, tasks: taskStats, files: fileStats, links: linkStats },
            recent_activity: recentActivity,
            user_growth: userGrowth
        });
    } catch (err) {
        console.error('Admin stats error:', err);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// GET /api/admin/activity
router.get('/activity', async (req, res) => {
    try {
        const [logs] = await db.execute(`
            SELECT al.*, u.name, u.email FROM activity_logs al
            JOIN users u ON al.user_id = u.id
            ORDER BY al.created_at DESC LIMIT 100
        `);
        res.json({ success: true, logs });
    } catch (err) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

module.exports = router;
