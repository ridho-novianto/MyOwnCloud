const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../db');
const { authMiddleware, adminMiddleware } = require('../middleware/auth');

// POST /api/auth/login
router.post('/login', async (req, res) => {
    try {
        const { email, password } = req.body;
        if (!email || !password) {
            return res.status(400).json({ success: false, message: 'Email dan password wajib diisi' });
        }

        const [rows] = await db.execute('SELECT * FROM users WHERE email = ? AND is_active = 1', [email]);
        if (!rows.length) {
            return res.status(401).json({ success: false, message: 'Email atau password salah' });
        }

        const user = rows[0];
        const valid = await bcrypt.compare(password, user.password);
        if (!valid) {
            return res.status(401).json({ success: false, message: 'Email atau password salah' });
        }

        await db.execute('UPDATE users SET last_login = NOW() WHERE id = ?', [user.id]);

        // Log activity
        await db.execute('INSERT INTO activity_logs (user_id, action, details, ip_address) VALUES (?, ?, ?, ?)',
            [user.id, 'login', 'User login', req.ip]);

        const token = jwt.sign(
            { id: user.id, email: user.email, role: user.role },
            process.env.JWT_SECRET,
            { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
        );

        res.json({
            success: true,
            token,
            user: {
                id: user.id,
                name: user.name,
                email: user.email,
                role: user.role,
                avatar: user.avatar,
                storage_used: user.storage_used,
                storage_limit: user.storage_limit
            }
        });
    } catch (err) {
        console.error('Login error:', err);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// POST /api/auth/register (admin only bisa tambah user)
router.post('/register', authMiddleware, adminMiddleware, async (req, res) => {
    try {
        const { name, email, password, role, storage_limit } = req.body;
        if (!name || !email || !password) {
            return res.status(400).json({ success: false, message: 'Name, email, password wajib diisi' });
        }

        const [existing] = await db.execute('SELECT id FROM users WHERE email = ?', [email]);
        if (existing.length) {
            return res.status(409).json({ success: false, message: 'Email sudah terdaftar' });
        }

        const hashed = await bcrypt.hash(password, 12);
        const limit = storage_limit || 5368709120; // 5GB default

        const [result] = await db.execute(
            'INSERT INTO users (name, email, password, role, storage_limit) VALUES (?, ?, ?, ?, ?)',
            [name, email, hashed, role || 'user', limit]
        );

        res.status(201).json({
            success: true,
            message: 'User berhasil dibuat',
            user_id: result.insertId
        });
    } catch (err) {
        console.error('Register error:', err);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// GET /api/auth/me
router.get('/me', authMiddleware, async (req, res) => {
    res.json({ success: true, user: req.user });
});

// PUT /api/auth/profile
router.put('/profile', authMiddleware, async (req, res) => {
    try {
        const { name, current_password, new_password } = req.body;
        const updates = [];
        const values = [];

        if (name) {
            updates.push('name = ?');
            values.push(name);
        }

        if (new_password) {
            if (!current_password) {
                return res.status(400).json({ success: false, message: 'Password lama wajib diisi' });
            }
            const [rows] = await db.execute('SELECT password FROM users WHERE id = ?', [req.user.id]);
            const valid = await bcrypt.compare(current_password, rows[0].password);
            if (!valid) {
                return res.status(400).json({ success: false, message: 'Password lama salah' });
            }
            const hashed = await bcrypt.hash(new_password, 12);
            updates.push('password = ?');
            values.push(hashed);
        }

        if (!updates.length) {
            return res.status(400).json({ success: false, message: 'Tidak ada yang diubah' });
        }

        values.push(req.user.id);
        await db.execute(`UPDATE users SET ${updates.join(', ')} WHERE id = ?`, values);

        res.json({ success: true, message: 'Profil berhasil diupdate' });
    } catch (err) {
        console.error('Profile update error:', err);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// GET /api/auth/dashboard-stats
router.get('/dashboard-stats', authMiddleware, async (req, res) => {
    try {
        const userId = req.user.id;
        const isAdmin = req.user.role === 'admin';

        const targetId = isAdmin ? null : userId;
        const userFilter = targetId ? 'WHERE user_id = ?' : '';
        const params = targetId ? [userId] : [];

        const [[taskStats]] = await db.execute(`
            SELECT 
                COUNT(*) as total,
                SUM(status = 'done') as done,
                SUM(status = 'in_progress') as in_progress,
                SUM(status = 'todo') as todo,
                SUM(status = 'cancelled') as cancelled,
                SUM(deadline < NOW() AND status NOT IN ('done','cancelled')) as overdue
            FROM tasks ${userFilter}
        `, params);

        const [[linkStats]] = await db.execute(
            `SELECT COUNT(*) as total, SUM(click_count) as total_clicks FROM links ${userFilter}`, params);

        const [[fileStats]] = await db.execute(
            `SELECT COUNT(*) as total, SUM(file_size) as total_size FROM files ${userFilter}`, params);

        const [recentTasks] = await db.execute(`
            SELECT id, title, status, priority, deadline FROM tasks 
            ${userFilter}
            ORDER BY created_at DESC LIMIT 5
        `, params);

        const [upcomingDeadlines] = await db.execute(`
            SELECT id, title, status, priority, deadline FROM tasks 
            WHERE ${targetId ? 'user_id = ? AND' : ''} deadline > NOW() AND status NOT IN ('done','cancelled')
            ORDER BY deadline ASC LIMIT 5
        `, params);

        // Weekly task completion (last 7 days)
        const [weeklyChart] = await db.execute(`
            SELECT DATE(updated_at) as date, COUNT(*) as count
            FROM tasks 
            WHERE ${targetId ? 'user_id = ? AND' : ''} status = 'done' 
            AND updated_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
            GROUP BY DATE(updated_at)
            ORDER BY date ASC
        `, params);

        let adminStats = null;
        if (isAdmin) {
            const [[us]] = await db.execute('SELECT COUNT(*) as total, SUM(is_active=1) as active FROM users');
            adminStats = { total_users: us.total, active_users: us.active };
        }

        res.json({
            success: true,
            data: {
                tasks: taskStats,
                links: linkStats,
                files: fileStats,
                recent_tasks: recentTasks,
                upcoming_deadlines: upcomingDeadlines,
                weekly_chart: weeklyChart,
                admin: adminStats,
                user: {
                    storage_used: req.user.storage_used,
                    storage_limit: req.user.storage_limit
                }
            }
        });
    } catch (err) {
        console.error('Dashboard stats error:', err);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

module.exports = router;
