const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const mime = require('mime-types');
const db = require('../db');
const { authMiddleware, adminMiddleware } = require('../middleware/auth');

// Multer storage config
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const dir = path.join(__dirname, '../uploads', String(req.user.id));
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
        cb(null, dir);
    },
    filename: (req, file, cb) => {
        const unique = Date.now() + '-' + Math.round(Math.random() * 1E6);
        const ext = path.extname(file.originalname);
        cb(null, unique + ext);
    }
});

const upload = multer({
    storage,
    limits: { fileSize: parseInt(process.env.MAX_FILE_SIZE) || 104857600 }, // 100MB
    fileFilter: (req, file, cb) => {
        // Block dangerous extensions
        const blocked = ['.exe', '.bat', '.cmd', '.sh', '.php', '.py', '.js', '.msi'];
        const ext = path.extname(file.originalname).toLowerCase();
        if (blocked.includes(ext)) {
            return cb(new Error('Tipe file tidak diizinkan'));
        }
        cb(null, true);
    }
});

const getFileType = (mimeType) => {
    if (!mimeType) return 'other';
    if (mimeType.startsWith('image/')) return 'image';
    if (mimeType.startsWith('video/')) return 'video';
    if (mimeType.startsWith('audio/')) return 'audio';
    if (['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
         'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
         'text/plain', 'text/csv'].includes(mimeType)) return 'document';
    if (['application/zip', 'application/x-rar-compressed', 'application/x-7z-compressed',
         'application/gzip', 'application/x-tar'].includes(mimeType)) return 'archive';
    return 'other';
};

// GET /api/files
router.get('/', authMiddleware, async (req, res) => {
    try {
        const { folder_id, file_type, search, starred } = req.query;
        const isAdmin = req.user.role === 'admin';

        let query = `SELECT f.*, u.name as user_name, fo.name as folder_name
                     FROM files f 
                     JOIN users u ON f.user_id = u.id
                     LEFT JOIN folders fo ON f.folder_id = fo.id
                     WHERE ${isAdmin ? '1=1' : 'f.user_id = ?'}`;
        const params = isAdmin ? [] : [req.user.id];

        if (folder_id !== undefined) {
            if (folder_id === 'null' || folder_id === '') {
                query += ' AND f.folder_id IS NULL';
            } else {
                query += ' AND f.folder_id = ?'; params.push(folder_id);
            }
        }
        if (file_type) { query += ' AND f.file_type = ?'; params.push(file_type); }
        if (starred === '1') { query += ' AND f.is_starred = 1'; }
        if (search) { query += ' AND f.original_name LIKE ?'; params.push(`%${search}%`); }

        query += ' ORDER BY f.created_at DESC';

        const [files] = await db.execute(query, params);

        // Get folders
        const [folders] = await db.execute(
            `SELECT * FROM folders WHERE ${isAdmin ? '1=1' : 'user_id = ?'} ORDER BY name`,
            isAdmin ? [] : [req.user.id]
        );

        // Storage stats
        const [[storageStats]] = await db.execute(
            `SELECT SUM(file_size) as used, COUNT(*) as count FROM files WHERE ${isAdmin ? '1=1' : 'user_id = ?'}`,
            isAdmin ? [] : [req.user.id]
        );

        res.json({ success: true, files, folders, storage: storageStats });
    } catch (err) {
        console.error('Get files error:', err);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// POST /api/files/upload
router.post('/upload', authMiddleware, (req, res) => {
    upload.array('files', 10)(req, res, async (err) => {
        if (err) {
            return res.status(400).json({ success: false, message: err.message });
        }

        try {
            if (!req.files || !req.files.length) {
                return res.status(400).json({ success: false, message: 'Tidak ada file yang diupload' });
            }

            // Check storage limit
            const totalSize = req.files.reduce((sum, f) => sum + f.size, 0);
            if (req.user.storage_used + totalSize > req.user.storage_limit) {
                // Delete uploaded files
                req.files.forEach(f => fs.unlinkSync(f.path));
                return res.status(400).json({ success: false, message: 'Storage limit terlampaui' });
            }

            const { folder_id } = req.body;
            const uploadedFiles = [];

            for (const file of req.files) {
                const mimeType = mime.lookup(file.originalname) || file.mimetype;
                const fileType = getFileType(mimeType);

                const [result] = await db.execute(
                    'INSERT INTO files (user_id, original_name, stored_name, file_path, file_size, mime_type, file_type, folder_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                    [req.user.id, file.originalname, file.filename, file.path,
                     file.size, mimeType, fileType, folder_id || null]
                );

                uploadedFiles.push({ id: result.insertId, name: file.originalname, size: file.size });
            }

            // Update storage used
            await db.execute('UPDATE users SET storage_used = storage_used + ? WHERE id = ?', [totalSize, req.user.id]);

            res.json({ success: true, message: `${req.files.length} file berhasil diupload`, files: uploadedFiles });
        } catch (err) {
            console.error('Upload error:', err);
            res.status(500).json({ success: false, message: 'Server error' });
        }
    });
});

// GET /api/files/:id/download
router.get('/:id/download', authMiddleware, async (req, res) => {
    try {
        const [rows] = await db.execute('SELECT * FROM files WHERE id = ?', [req.params.id]);
        if (!rows.length) return res.status(404).json({ success: false, message: 'File tidak ditemukan' });

        const file = rows[0];
        if (req.user.role !== 'admin' && file.user_id !== req.user.id) {
            return res.status(403).json({ success: false, message: 'Akses ditolak' });
        }

        if (!fs.existsSync(file.file_path)) {
            return res.status(404).json({ success: false, message: 'File fisik tidak ditemukan' });
        }

        await db.execute('UPDATE files SET download_count = download_count + 1 WHERE id = ?', [file.id]);

        res.setHeader('Content-Disposition', `attachment; filename="${encodeURIComponent(file.original_name)}"`);
        res.setHeader('Content-Type', file.mime_type || 'application/octet-stream');
        res.setHeader('Content-Length', file.file_size);
        res.sendFile(path.resolve(file.file_path));
    } catch (err) {
        console.error('Download error:', err);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// GET /api/files/:id/preview
router.get('/:id/preview', authMiddleware, async (req, res) => {
    try {
        const [rows] = await db.execute('SELECT * FROM files WHERE id = ?', [req.params.id]);
        if (!rows.length) return res.status(404).json({ success: false, message: 'File tidak ditemukan' });

        const file = rows[0];
        if (req.user.role !== 'admin' && file.user_id !== req.user.id) {
            return res.status(403).json({ success: false, message: 'Akses ditolak' });
        }

        if (!fs.existsSync(file.file_path)) {
            return res.status(404).json({ success: false, message: 'File tidak ditemukan' });
        }

        res.setHeader('Content-Type', file.mime_type || 'application/octet-stream');
        res.sendFile(path.resolve(file.file_path));
    } catch (err) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// PUT /api/files/:id/star
router.put('/:id/star', authMiddleware, async (req, res) => {
    try {
        const [rows] = await db.execute('SELECT * FROM files WHERE id = ?', [req.params.id]);
        if (!rows.length || (req.user.role !== 'admin' && rows[0].user_id !== req.user.id)) {
            return res.status(404).json({ success: false, message: 'File tidak ditemukan' });
        }
        const newStar = rows[0].is_starred ? 0 : 1;
        await db.execute('UPDATE files SET is_starred = ? WHERE id = ?', [newStar, req.params.id]);
        res.json({ success: true, is_starred: newStar });
    } catch (err) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// DELETE /api/files/:id
router.delete('/:id', authMiddleware, async (req, res) => {
    try {
        const [rows] = await db.execute('SELECT * FROM files WHERE id = ?', [req.params.id]);
        if (!rows.length) return res.status(404).json({ success: false, message: 'File tidak ditemukan' });

        const file = rows[0];
        if (req.user.role !== 'admin' && file.user_id !== req.user.id) {
            return res.status(403).json({ success: false, message: 'Akses ditolak' });
        }

        // Delete physical file
        if (fs.existsSync(file.file_path)) {
            fs.unlinkSync(file.file_path);
        }

        await db.execute('DELETE FROM files WHERE id = ?', [file.id]);
        await db.execute('UPDATE users SET storage_used = GREATEST(0, storage_used - ?) WHERE id = ?',
            [file.file_size, file.user_id]);

        res.json({ success: true, message: 'File dihapus' });
    } catch (err) {
        console.error('Delete file error:', err);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// POST /api/files/folder
router.post('/folder', authMiddleware, async (req, res) => {
    try {
        const { name, parent_id, color } = req.body;
        if (!name) return res.status(400).json({ success: false, message: 'Nama folder wajib diisi' });

        const [result] = await db.execute(
            'INSERT INTO folders (user_id, name, parent_id, color) VALUES (?, ?, ?, ?)',
            [req.user.id, name, parent_id || null, color || '#6366f1']
        );

        res.status(201).json({ success: true, folder: { id: result.insertId, name, color: color || '#6366f1' } });
    } catch (err) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

module.exports = router;
