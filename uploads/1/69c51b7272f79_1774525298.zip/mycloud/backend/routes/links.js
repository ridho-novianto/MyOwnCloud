const express = require('express');
const router = express.Router();
const db = require('../db');
const { authMiddleware } = require('../middleware/auth');

// GET /api/links
router.get('/', authMiddleware, async (req, res) => {
    try {
        const { category, search } = req.query;
        const isAdmin = req.user.role === 'admin';

        let query = `SELECT l.*, u.name as user_name FROM links l 
                     JOIN users u ON l.user_id = u.id 
                     WHERE ${isAdmin ? '1=1' : 'l.user_id = ?'}`;
        const params = isAdmin ? [] : [req.user.id];

        if (category && category !== 'all') { query += ' AND l.category = ?'; params.push(category); }
        if (search) { query += ' AND (l.title LIKE ? OR l.url LIKE ? OR l.description LIKE ?)'; params.push(`%${search}%`, `%${search}%`, `%${search}%`); }

        query += ' ORDER BY l.is_pinned DESC, l.sort_order ASC, l.created_at DESC';

        const [links] = await db.execute(query, params);

        // Get categories
        const [categories] = await db.execute(
            `SELECT DISTINCT category, COUNT(*) as count FROM links WHERE ${isAdmin ? '1=1' : 'user_id = ?'} GROUP BY category`,
            isAdmin ? [] : [req.user.id]
        );

        res.json({ success: true, links, categories });
    } catch (err) {
        console.error('Get links error:', err);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// POST /api/links
router.post('/', authMiddleware, async (req, res) => {
    try {
        const { title, url, description, icon, category, color, is_pinned } = req.body;
        if (!title || !url) return res.status(400).json({ success: false, message: 'Judul dan URL wajib diisi' });

        const [result] = await db.execute(
            'INSERT INTO links (user_id, title, url, description, icon, category, color, is_pinned) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
            [req.user.id, title, url, description || null, icon || '🔗', category || 'General', color || '#6366f1', is_pinned ? 1 : 0]
        );

        const [newLink] = await db.execute('SELECT * FROM links WHERE id = ?', [result.insertId]);
        res.status(201).json({ success: true, link: newLink[0] });
    } catch (err) {
        console.error('Create link error:', err);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// PUT /api/links/:id
router.put('/:id', authMiddleware, async (req, res) => {
    try {
        const { title, url, description, icon, category, color, is_pinned } = req.body;
        const [rows] = await db.execute('SELECT * FROM links WHERE id = ?', [req.params.id]);
        if (!rows.length) return res.status(404).json({ success: false, message: 'Link tidak ditemukan' });
        if (req.user.role !== 'admin' && rows[0].user_id !== req.user.id) {
            return res.status(403).json({ success: false, message: 'Akses ditolak' });
        }

        await db.execute(`
            UPDATE links SET 
                title = COALESCE(?, title), url = COALESCE(?, url),
                description = COALESCE(?, description), icon = COALESCE(?, icon),
                category = COALESCE(?, category), color = COALESCE(?, color),
                is_pinned = COALESCE(?, is_pinned)
            WHERE id = ?
        `, [title, url, description, icon, category, color, is_pinned !== undefined ? (is_pinned ? 1 : 0) : null, req.params.id]);

        const [updated] = await db.execute('SELECT * FROM links WHERE id = ?', [req.params.id]);
        res.json({ success: true, link: updated[0] });
    } catch (err) {
        console.error('Update link error:', err);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// POST /api/links/:id/click (track click)
router.post('/:id/click', authMiddleware, async (req, res) => {
    try {
        await db.execute('UPDATE links SET click_count = click_count + 1 WHERE id = ?', [req.params.id]);
        const [link] = await db.execute('SELECT url FROM links WHERE id = ?', [req.params.id]);
        res.json({ success: true, url: link[0]?.url });
    } catch (err) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// DELETE /api/links/:id
router.delete('/:id', authMiddleware, async (req, res) => {
    try {
        const [rows] = await db.execute('SELECT * FROM links WHERE id = ?', [req.params.id]);
        if (!rows.length) return res.status(404).json({ success: false, message: 'Link tidak ditemukan' });
        if (req.user.role !== 'admin' && rows[0].user_id !== req.user.id) {
            return res.status(403).json({ success: false, message: 'Akses ditolak' });
        }

        await db.execute('DELETE FROM links WHERE id = ?', [req.params.id]);
        res.json({ success: true, message: 'Link dihapus' });
    } catch (err) {
        console.error('Delete link error:', err);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

module.exports = router;
