const express = require('express');
const router = express.Router();
const webpush = require('web-push');
const db = require('../db');
const { authMiddleware } = require('../middleware/auth');

// Configure VAPID
if (process.env.VAPID_PUBLIC_KEY && process.env.VAPID_PRIVATE_KEY) {
    webpush.setVapidDetails(
        process.env.VAPID_EMAIL || 'mailto:admin@mycloud.local',
        process.env.VAPID_PUBLIC_KEY,
        process.env.VAPID_PRIVATE_KEY
    );
}

// GET /api/notify/vapid-public-key
router.get('/vapid-public-key', (req, res) => {
    res.json({ success: true, key: process.env.VAPID_PUBLIC_KEY || '' });
});

// POST /api/notify/subscribe
router.post('/subscribe', authMiddleware, async (req, res) => {
    try {
        const { endpoint, keys } = req.body;
        if (!endpoint || !keys?.p256dh || !keys?.auth) {
            return res.status(400).json({ success: false, message: 'Data subscription tidak lengkap' });
        }

        await db.execute(`
            INSERT INTO push_subscriptions (user_id, endpoint, p256dh, auth, user_agent)
            VALUES (?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE p256dh = ?, auth = ?
        `, [req.user.id, endpoint, keys.p256dh, keys.auth, req.headers['user-agent'] || '',
            keys.p256dh, keys.auth]);

        res.json({ success: true, message: 'Notifikasi berhasil diaktifkan' });
    } catch (err) {
        console.error('Subscribe error:', err);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// POST /api/notify/unsubscribe
router.post('/unsubscribe', authMiddleware, async (req, res) => {
    try {
        const { endpoint } = req.body;
        await db.execute('DELETE FROM push_subscriptions WHERE user_id = ? AND endpoint = ?',
            [req.user.id, endpoint]);
        res.json({ success: true, message: 'Notifikasi dinonaktifkan' });
    } catch (err) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// POST /api/notify/test (test notification)
router.post('/test', authMiddleware, async (req, res) => {
    try {
        const [subs] = await db.execute('SELECT * FROM push_subscriptions WHERE user_id = ?', [req.user.id]);
        if (!subs.length) {
            return res.status(400).json({ success: false, message: 'Belum ada subscription. Aktifkan notifikasi dulu.' });
        }

        const payload = JSON.stringify({
            title: '🔔 MyCloud Notification',
            body: 'Notifikasi berhasil! Kamu akan dapat reminder deadline task.',
            icon: '/icons/icon-192.png',
            badge: '/icons/badge-72.png',
            url: '/pages/tasks.html'
        });

        let sent = 0;
        for (const sub of subs) {
            try {
                await webpush.sendNotification({ endpoint: sub.endpoint, keys: { p256dh: sub.p256dh, auth: sub.auth } }, payload);
                sent++;
            } catch (e) {
                if (e.statusCode === 410) {
                    await db.execute('DELETE FROM push_subscriptions WHERE id = ?', [sub.id]);
                }
            }
        }

        res.json({ success: true, message: `Test notifikasi dikirim ke ${sent} device` });
    } catch (err) {
        console.error('Test notify error:', err);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// === CRON JOB: Check deadlines & send notifications ===
const sendDeadlineNotifications = async () => {
    try {
        if (!process.env.VAPID_PUBLIC_KEY) return;

        const now = new Date();
        const in7days = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
        const in1day = new Date(now.getTime() + 24 * 60 * 60 * 1000);

        // Tasks due in 7 days (not yet notified)
        const [tasks7days] = await db.execute(`
            SELECT t.*, u.name as user_name FROM tasks t
            JOIN users u ON t.user_id = u.id
            WHERE t.deadline BETWEEN ? AND ?
            AND t.status NOT IN ('done', 'cancelled')
            AND t.notified_7days = 0
        `, [now.toISOString(), in7days.toISOString()]);

        for (const task of tasks7days) {
            const daysLeft = Math.ceil((new Date(task.deadline) - now) / (1000 * 60 * 60 * 24));
            await sendToUser(task.user_id, {
                title: `⚠️ Deadline dalam ${daysLeft} hari`,
                body: `Task: ${task.title}`,
                url: '/pages/tasks.html'
            });
            await db.execute('UPDATE tasks SET notified_7days = 1 WHERE id = ?', [task.id]);
            await db.execute('INSERT INTO notification_logs (user_id, task_id, type, message) VALUES (?, ?, ?, ?)',
                [task.user_id, task.id, '7days', `Deadline reminder: ${task.title}`]);
        }

        // Tasks due in 1 day
        const [tasks1day] = await db.execute(`
            SELECT t.*, u.name as user_name FROM tasks t
            WHERE t.deadline BETWEEN ? AND ?
            AND t.status NOT IN ('done', 'cancelled')
            AND t.notified_1day = 0
        `, [now.toISOString(), in1day.toISOString()]);

        for (const task of tasks1day) {
            await sendToUser(task.user_id, {
                title: `🚨 Deadline BESOK!`,
                body: `Task: ${task.title} - Segera selesaikan!`,
                url: '/pages/tasks.html'
            });
            await db.execute('UPDATE tasks SET notified_1day = 1 WHERE id = ?', [task.id]);
        }

        // Overdue tasks
        const [overdues] = await db.execute(`
            SELECT * FROM tasks
            WHERE deadline < ?
            AND status NOT IN ('done', 'cancelled')
            AND notified_overdue = 0
        `, [now.toISOString()]);

        for (const task of overdues) {
            await sendToUser(task.user_id, {
                title: `❌ Task Terlambat!`,
                body: `"${task.title}" sudah melewati deadline`,
                url: '/pages/tasks.html'
            });
            await db.execute('UPDATE tasks SET notified_overdue = 1 WHERE id = ?', [task.id]);
        }

        if (tasks7days.length + tasks1day.length + overdues.length > 0) {
            console.log(`📬 Sent notifications: ${tasks7days.length} (7days), ${tasks1day.length} (1day), ${overdues.length} (overdue)`);
        }
    } catch (err) {
        console.error('Cron notification error:', err);
    }
};

const sendToUser = async (userId, payload) => {
    const [subs] = await db.execute('SELECT * FROM push_subscriptions WHERE user_id = ?', [userId]);
    for (const sub of subs) {
        try {
            await webpush.sendNotification(
                { endpoint: sub.endpoint, keys: { p256dh: sub.p256dh, auth: sub.auth } },
                JSON.stringify({ ...payload, icon: '/icons/icon-192.png', badge: '/icons/badge-72.png' })
            );
        } catch (e) {
            if (e.statusCode === 410) {
                await db.execute('DELETE FROM push_subscriptions WHERE id = ?', [sub.id]);
            }
        }
    }
};

module.exports = { router, sendDeadlineNotifications };
