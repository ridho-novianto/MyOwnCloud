const express = require('express');
const router = express.Router();
const db = require('../db');
const { authMiddleware, adminMiddleware } = require('../middleware/auth');

// GET /api/tasks
router.get('/', authMiddleware, async (req, res) => {
    try {
        const { status, priority, search, sort = 'deadline', order = 'ASC' } = req.query;
        const isAdmin = req.user.role === 'admin';

        let query = `SELECT t.*, u.name as user_name FROM tasks t 
                     JOIN users u ON t.user_id = u.id 
                     WHERE ${isAdmin ? '1=1' : 't.user_id = ?'}`;
        const params = isAdmin ? [] : [req.user.id];

        if (status) { query += ' AND t.status = ?'; params.push(status); }
        if (priority) { query += ' AND t.priority = ?'; params.push(priority); }
        if (search) { query += ' AND (t.title LIKE ? OR t.description LIKE ?)'; params.push(`%${search}%`, `%${search}%`); }

        const allowedSort = ['deadline', 'created_at', 'priority', 'status', 'title'];
        const sortCol = allowedSort.includes(sort) ? sort : 'deadline';
        const sortOrder = order === 'DESC' ? 'DESC' : 'ASC';
        query += ` ORDER BY t.${sortCol} IS NULL, t.${sortCol} ${sortOrder}, t.created_at DESC`;

        const [tasks] = await db.execute(query, params);

        // Count by status for summary
        const [[summary]] = await db.execute(`
            SELECT 
                COUNT(*) as total,
                SUM(status='todo') as todo,
                SUM(status='in_progress') as in_progress,
                SUM(status='done') as done,
                SUM(status='cancelled') as cancelled,
                SUM(deadline < NOW() AND status NOT IN ('done','cancelled')) as overdue
            FROM tasks WHERE ${isAdmin ? '1=1' : 'user_id = ?'}
        `, isAdmin ? [] : [req.user.id]);

        res.json({ success: true, tasks, summary });
    } catch (err) {
        console.error('Get tasks error:', err);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// POST /api/tasks
router.post('/', authMiddleware, async (req, res) => {
    try {
        const { title, description, status, priority, deadline, tags } = req.body;
        if (!title) return res.status(400).json({ success: false, message: 'Judul task wajib diisi' });

        const [result] = await db.execute(
            'INSERT INTO tasks (user_id, title, description, status, priority, deadline, tags) VALUES (?, ?, ?, ?, ?, ?, ?)',
            [req.user.id, title, description || null, status || 'todo', priority || 'medium', deadline || null, tags || null]
        );

        const [newTask] = await db.execute('SELECT * FROM tasks WHERE id = ?', [result.insertId]);
        res.status(201).json({ success: true, task: newTask[0] });
    } catch (err) {
        console.error('Create task error:', err);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// PUT /api/tasks/:id
router.put('/:id', authMiddleware, async (req, res) => {
    try {
        const { title, description, status, priority, deadline, tags } = req.body;
        const isAdmin = req.user.role === 'admin';

        const [rows] = await db.execute('SELECT * FROM tasks WHERE id = ?', [req.params.id]);
        if (!rows.length) return res.status(404).json({ success: false, message: 'Task tidak ditemukan' });
        if (!isAdmin && rows[0].user_id !== req.user.id) {
            return res.status(403).json({ success: false, message: 'Akses ditolak' });
        }

        await db.execute(`
            UPDATE tasks SET 
                title = COALESCE(?, title),
                description = COALESCE(?, description),
                status = COALESCE(?, status),
                priority = COALESCE(?, priority),
                deadline = COALESCE(?, deadline),
                tags = COALESCE(?, tags)
            WHERE id = ?
        `, [title, description, status, priority, deadline, tags, req.params.id]);

        const [updated] = await db.execute('SELECT * FROM tasks WHERE id = ?', [req.params.id]);
        res.json({ success: true, task: updated[0] });
    } catch (err) {
        console.error('Update task error:', err);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// DELETE /api/tasks/:id
router.delete('/:id', authMiddleware, async (req, res) => {
    try {
        const isAdmin = req.user.role === 'admin';
        const [rows] = await db.execute('SELECT * FROM tasks WHERE id = ?', [req.params.id]);
        if (!rows.length) return res.status(404).json({ success: false, message: 'Task tidak ditemukan' });
        if (!isAdmin && rows[0].user_id !== req.user.id) {
            return res.status(403).json({ success: false, message: 'Akses ditolak' });
        }

        await db.execute('DELETE FROM tasks WHERE id = ?', [req.params.id]);
        res.json({ success: true, message: 'Task dihapus' });
    } catch (err) {
        console.error('Delete task error:', err);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

module.exports = router;
