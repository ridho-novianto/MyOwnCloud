require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const cron = require('node-cron');

const app = express();
const PORT = process.env.PORT || 3000;

// =============================================
// Middleware
// =============================================
app.use(cors({
    origin: process.env.NODE_ENV === 'production' ? process.env.BASE_URL : '*',
    credentials: true
}));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Request logging
app.use((req, res, next) => {
    if (req.path.startsWith('/api')) {
        console.log(`[${new Date().toISOString()}] ${req.method} ${req.path}`);
    }
    next();
});

// =============================================
// Static Files (Frontend)
// =============================================
app.use(express.static(path.join(__dirname, '../frontend')));

// =============================================
// API Routes
// =============================================
const authRoutes = require('./routes/auth');
const taskRoutes = require('./routes/tasks');
const linkRoutes = require('./routes/links');
const fileRoutes = require('./routes/files');
const adminRoutes = require('./routes/admin');
const { router: notifyRoutes, sendDeadlineNotifications } = require('./routes/notify');

app.use('/api/auth', authRoutes);
app.use('/api/tasks', taskRoutes);
app.use('/api/links', linkRoutes);
app.use('/api/files', fileRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/notify', notifyRoutes);

// Health check
app.get('/api/health', (req, res) => {
    res.json({ 
        status: 'OK', 
        timestamp: new Date().toISOString(),
        version: '1.0.0',
        uptime: process.uptime()
    });
});

// =============================================
// Serve Frontend Pages (SPA-like routing)
// =============================================
app.get('/pages/*', (req, res) => {
    const page = req.params[0];
    res.sendFile(path.join(__dirname, '../frontend/pages', page));
});

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

// 404 handler
app.use((req, res) => {
    if (req.path.startsWith('/api')) {
        return res.status(404).json({ success: false, message: 'Endpoint tidak ditemukan' });
    }
    res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

// Error handler
app.use((err, req, res, next) => {
    console.error('Error:', err.message);
    res.status(500).json({ success: false, message: 'Internal server error' });
});

// =============================================
// CRON JOBS
// =============================================
// Check deadlines every hour
cron.schedule('0 * * * *', () => {
    console.log('⏰ Running deadline notification check...');
    sendDeadlineNotifications();
});

// Also run at startup
setTimeout(sendDeadlineNotifications, 5000);

// =============================================
// Start Server
// =============================================
app.listen(PORT, '0.0.0.0', () => {
    console.log('');
    console.log('╔══════════════════════════════════════╗');
    console.log('║          MyCloud Server              ║');
    console.log('╠══════════════════════════════════════╣');
    console.log(`║  Running on port: ${PORT}               ║`);
    console.log(`║  Mode: ${process.env.NODE_ENV || 'development'}                  ║`);
    console.log(`║  URL: http://localhost:${PORT}           ║`);
    console.log('╚══════════════════════════════════════╝');
    console.log('');
});

module.exports = app;
