-- =============================================
-- MyCloud Database Schema
-- =============================================
-- Run: mysql -u root -p < database.sql

CREATE DATABASE IF NOT EXISTS mycloud_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE mycloud_db;

-- =============================================
-- USERS
-- =============================================
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'user') DEFAULT 'user',
    avatar VARCHAR(255) DEFAULT NULL,
    storage_used BIGINT DEFAULT 0,
    storage_limit BIGINT DEFAULT 5368709120, -- 5GB default
    is_active TINYINT(1) DEFAULT 1,
    last_login DATETIME DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- =============================================
-- TASKS / TODO
-- =============================================
CREATE TABLE IF NOT EXISTS tasks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT DEFAULT NULL,
    status ENUM('todo', 'in_progress', 'done', 'cancelled') DEFAULT 'todo',
    priority ENUM('low', 'medium', 'high', 'urgent') DEFAULT 'medium',
    deadline DATETIME DEFAULT NULL,
    notified_7days TINYINT(1) DEFAULT 0,
    notified_1day TINYINT(1) DEFAULT 0,
    notified_overdue TINYINT(1) DEFAULT 0,
    tags VARCHAR(500) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_deadline (user_id, deadline),
    INDEX idx_status (status)
);

-- =============================================
-- LINKS (Link Manager)
-- =============================================
CREATE TABLE IF NOT EXISTS links (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    url TEXT NOT NULL,
    description VARCHAR(500) DEFAULT NULL,
    icon VARCHAR(10) DEFAULT '🔗',
    category VARCHAR(100) DEFAULT 'General',
    color VARCHAR(20) DEFAULT '#6366f1',
    click_count INT DEFAULT 0,
    is_pinned TINYINT(1) DEFAULT 0,
    sort_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_category (user_id, category),
    INDEX idx_pinned (is_pinned)
);

-- =============================================
-- FILES
-- =============================================
CREATE TABLE IF NOT EXISTS files (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    original_name VARCHAR(500) NOT NULL,
    stored_name VARCHAR(500) NOT NULL,
    file_path VARCHAR(1000) NOT NULL,
    file_size BIGINT NOT NULL,
    mime_type VARCHAR(200) DEFAULT NULL,
    file_type ENUM('image', 'video', 'audio', 'document', 'archive', 'other') DEFAULT 'other',
    folder_id INT DEFAULT NULL,
    is_starred TINYINT(1) DEFAULT 0,
    download_count INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_folder (user_id, folder_id),
    INDEX idx_file_type (file_type)
);

-- =============================================
-- FOLDERS
-- =============================================
CREATE TABLE IF NOT EXISTS folders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    name VARCHAR(255) NOT NULL,
    parent_id INT DEFAULT NULL,
    color VARCHAR(20) DEFAULT '#6366f1',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (parent_id) REFERENCES folders(id) ON DELETE CASCADE
);

-- Add folder FK after folders table created
ALTER TABLE files ADD CONSTRAINT fk_files_folder 
    FOREIGN KEY (folder_id) REFERENCES folders(id) ON DELETE SET NULL;

-- =============================================
-- PUSH SUBSCRIPTIONS (Web Push Notifications)
-- =============================================
CREATE TABLE IF NOT EXISTS push_subscriptions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    endpoint TEXT NOT NULL,
    p256dh TEXT NOT NULL,
    auth TEXT NOT NULL,
    user_agent VARCHAR(500) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_endpoint (user_id, endpoint(500))
);

-- =============================================
-- NOTIFICATIONS LOG
-- =============================================
CREATE TABLE IF NOT EXISTS notification_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    task_id INT DEFAULT NULL,
    type VARCHAR(50) NOT NULL,
    message TEXT NOT NULL,
    sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- =============================================
-- ACTIVITY LOG
-- =============================================
CREATE TABLE IF NOT EXISTS activity_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    action VARCHAR(100) NOT NULL,
    details TEXT DEFAULT NULL,
    ip_address VARCHAR(45) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_created (user_id, created_at)
);

-- =============================================
-- DEFAULT ADMIN USER
-- Password: Admin@123456 (bcrypt hash)
-- GANTI PASSWORD SETELAH LOGIN PERTAMA!
-- =============================================
INSERT INTO users (name, email, password, role, storage_limit) VALUES 
('Administrator', 'admin@mycloud.local', '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj/RK.s5uADi', 'admin', 107374182400);
-- storage_limit admin = 100GB

-- =============================================
-- SAMPLE DATA (optional - hapus jika tidak perlu)
-- =============================================
INSERT INTO links (user_id, title, url, description, icon, category, color, is_pinned) VALUES
(1, 'GitHub', 'https://github.com', 'Code repository', '🐙', 'Development', '#24292e', 1),
(1, 'Google Drive', 'https://drive.google.com', 'Cloud storage', '📂', 'Productivity', '#4285f4', 1),
(1, 'ChatGPT', 'https://chat.openai.com', 'AI Assistant', '🤖', 'AI Tools', '#10a37f', 0);

INSERT INTO tasks (user_id, title, description, status, priority, deadline) VALUES
(1, 'Setup VPS Server', 'Install nginx, MySQL, Node.js on VPS', 'in_progress', 'high', DATE_ADD(NOW(), INTERVAL 3 DAY)),
(1, 'Configure SSL Certificate', 'Setup Lets Encrypt for HTTPS', 'todo', 'urgent', DATE_ADD(NOW(), INTERVAL 7 DAY)),
(1, 'Backup Database', 'Setup automated MySQL backup', 'todo', 'medium', DATE_ADD(NOW(), INTERVAL 14 DAY));
