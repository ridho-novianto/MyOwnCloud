// =============================================
// MyCloud - Main App JS
// =============================================

const API_BASE = '/api';

// =============================================
// API Client
// =============================================
const api = {
    getToken: () => localStorage.getItem('mc_token'),
    getUser: () => JSON.parse(localStorage.getItem('mc_user') || 'null'),

    async request(method, endpoint, data = null) {
        const token = this.getToken();
        const headers = { 'Content-Type': 'application/json' };
        if (token) headers['Authorization'] = `Bearer ${token}`;

        const config = { method, headers };
        if (data) config.body = JSON.stringify(data);

        try {
            const res = await fetch(API_BASE + endpoint, config);
            const json = await res.json();

            if (res.status === 401) {
                localStorage.removeItem('mc_token');
                localStorage.removeItem('mc_user');
                window.location.href = '/';
                return;
            }

            return { ok: res.ok, status: res.status, data: json };
        } catch (err) {
            toast('Koneksi gagal. Periksa server.', 'error');
            throw err;
        }
    },

    get: (endpoint) => api.request('GET', endpoint),
    post: (endpoint, data) => api.request('POST', endpoint, data),
    put: (endpoint, data) => api.request('PUT', endpoint, data),
    delete: (endpoint) => api.request('DELETE', endpoint),

    async upload(endpoint, formData) {
        const token = this.getToken();
        const headers = {};
        if (token) headers['Authorization'] = `Bearer ${token}`;

        const res = await fetch(API_BASE + endpoint, { method: 'POST', headers, body: formData });
        const json = await res.json();
        return { ok: res.ok, data: json };
    }
};

// =============================================
// Auth Guard
// =============================================
function requireAuth() {
    const token = api.getToken();
    const user = api.getUser();
    if (!token || !user) {
        window.location.href = '/';
        return null;
    }
    return user;
}

function requireAdmin() {
    const user = requireAuth();
    if (user && user.role !== 'admin') {
        window.location.href = '/pages/dashboard.html';
        return null;
    }
    return user;
}

// =============================================
// Toast Notifications
// =============================================
function toast(message, type = 'info', duration = 3500) {
    let container = document.getElementById('toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toast-container';
        container.className = 'toast-container';
        document.body.appendChild(container);
    }

    const icons = { success: '✅', error: '❌', info: 'ℹ️', warning: '⚠️' };
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerHTML = `<span>${icons[type] || '🔔'}</span><span>${message}</span>`;
    container.appendChild(toast);

    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateX(20px)';
        toast.style.transition = 'all 0.3s';
        setTimeout(() => toast.remove(), 300);
    }, duration);
}

// =============================================
// Modal
// =============================================
function openModal(id) {
    const modal = document.getElementById(id);
    if (modal) modal.classList.add('active');
}

function closeModal(id) {
    const modal = document.getElementById(id);
    if (modal) modal.classList.remove('active');
}

// Close modal on overlay click
document.addEventListener('click', (e) => {
    if (e.target.classList.contains('modal-overlay')) {
        e.target.classList.remove('active');
    }
});

// Close on Escape
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
        document.querySelectorAll('.modal-overlay.active').forEach(m => m.classList.remove('active'));
    }
});

// =============================================
// Format Helpers
// =============================================
function formatBytes(bytes) {
    if (!bytes || bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
}

function formatDate(dateStr) {
    if (!dateStr) return '-';
    const d = new Date(dateStr);
    return d.toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' });
}

function formatDateTime(dateStr) {
    if (!dateStr) return '-';
    const d = new Date(dateStr);
    return d.toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}

function formatRelative(dateStr) {
    if (!dateStr) return '-';
    const d = new Date(dateStr);
    const now = new Date();
    const diff = d - now;
    const absDiff = Math.abs(diff);
    const days = Math.floor(absDiff / (1000 * 60 * 60 * 24));

    if (diff < 0) {
        if (days === 0) return '🔴 Terlambat hari ini';
        return `🔴 ${days} hari lalu`;
    }
    if (days === 0) return '🟡 Hari ini';
    if (days === 1) return '🟡 Besok';
    if (days <= 7) return `🟠 ${days} hari lagi`;
    return `🟢 ${formatDate(dateStr)}`;
}

function getFileIcon(type, mimeType) {
    const icons = {
        image: '🖼️', video: '🎬', audio: '🎵', document: '📄',
        archive: '📦', other: '📎'
    };
    if (mimeType?.includes('pdf')) return '📕';
    if (mimeType?.includes('word')) return '📘';
    if (mimeType?.includes('excel') || mimeType?.includes('spreadsheet')) return '📗';
    return icons[type] || '📎';
}

function getStatusLabel(status) {
    const labels = { todo: 'To Do', in_progress: 'In Progress', done: 'Done', cancelled: 'Cancelled' };
    return labels[status] || status;
}

function getPriorityLabel(priority) {
    const labels = { low: 'Low', medium: 'Medium', high: 'High', urgent: 'Urgent' };
    return labels[priority] || priority;
}

// =============================================
// Sidebar Setup
// =============================================
function setupSidebar(activePage) {
    const user = requireAuth();
    if (!user) return;

    const sidebar = document.getElementById('sidebar');
    if (!sidebar) return;

    // User card
    const initials = user.name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2);
    const userCard = sidebar.querySelector('.user-card');
    if (userCard) {
        userCard.querySelector('.user-avatar').textContent = initials;
        userCard.querySelector('.user-name').textContent = user.name;
        userCard.querySelector('.user-role').textContent = user.role.toUpperCase();
    }

    // Set active nav
    sidebar.querySelectorAll('.nav-item').forEach(item => {
        item.classList.remove('active');
        if (item.dataset.page === activePage) item.classList.add('active');
    });

    // Admin nav visibility
    const adminNav = sidebar.querySelector('[data-admin-only]');
    if (adminNav) {
        adminNav.style.display = user.role === 'admin' ? 'block' : 'none';
    }

    // Hamburger
    const hamburger = document.getElementById('hamburger');
    if (hamburger) {
        hamburger.addEventListener('click', () => sidebar.classList.toggle('open'));
    }
}

// =============================================
// Storage Bar
// =============================================
function renderStorageBar(used, limit) {
    const pct = limit ? Math.min((used / limit) * 100, 100) : 0;
    const color = pct > 90 ? 'var(--neon-pink)' : pct > 70 ? 'var(--neon-orange)' : 'var(--neon-blue)';
    return `
        <div style="margin-top: 8px;">
            <div style="display:flex;justify-content:space-between;font-size:11px;color:var(--text-secondary);margin-bottom:4px;">
                <span>${formatBytes(used)} digunakan</span>
                <span>${formatBytes(limit)}</span>
            </div>
            <div class="progress-bar">
                <div class="progress-fill" style="width:${pct}%;background:${color}"></div>
            </div>
        </div>
    `;
}

// =============================================
// Push Notifications Setup
// =============================================
async function setupPushNotifications() {
    if (!('serviceWorker' in navigator) || !('PushManager' in window)) {
        console.warn('Push not supported');
        return;
    }

    try {
        const reg = await navigator.serviceWorker.register('/js/sw.js');
        const { data } = await api.get('/notify/vapid-public-key');
        if (!data.key) return;

        const permission = await Notification.requestPermission();
        if (permission !== 'granted') return;

        const sub = await reg.pushManager.subscribe({
            userVisibleOnly: true,
            applicationServerKey: urlBase64ToUint8Array(data.key)
        });

        await api.post('/notify/subscribe', {
            endpoint: sub.endpoint,
            keys: { p256dh: arrayBufferToBase64(sub.getKey('p256dh')), auth: arrayBufferToBase64(sub.getKey('auth')) }
        });

        console.log('✅ Push notifications subscribed');
    } catch (err) {
        console.error('Push setup error:', err);
    }
}

function urlBase64ToUint8Array(base64String) {
    const padding = '='.repeat((4 - base64String.length % 4) % 4);
    const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
    const rawData = window.atob(base64);
    return new Uint8Array([...rawData].map(c => c.charCodeAt(0)));
}

function arrayBufferToBase64(buffer) {
    return btoa(String.fromCharCode(...new Uint8Array(buffer)));
}

// =============================================
// Confirm Dialog
// =============================================
function confirm(message, onConfirm) {
    if (window.confirm(message)) onConfirm();
}

// Expose globally
window.api = api;
window.toast = toast;
window.openModal = openModal;
window.closeModal = closeModal;
window.formatBytes = formatBytes;
window.formatDate = formatDate;
window.formatDateTime = formatDateTime;
window.formatRelative = formatRelative;
window.getFileIcon = getFileIcon;
window.getStatusLabel = getStatusLabel;
window.getPriorityLabel = getPriorityLabel;
window.setupSidebar = setupSidebar;
window.renderStorageBar = renderStorageBar;
window.setupPushNotifications = setupPushNotifications;
window.requireAuth = requireAuth;
window.requireAdmin = requireAdmin;
