// MyCloud Service Worker - Push Notifications
const CACHE_NAME = 'mycloud-v1';
const STATIC_ASSETS = ['/', '/css/style.css', '/js/app.js'];

// Install & cache
self.addEventListener('install', e => {
    e.waitUntil(caches.open(CACHE_NAME).then(c => c.addAll(STATIC_ASSETS)).catch(() => {}));
    self.skipWaiting();
});

// Activate
self.addEventListener('activate', e => {
    e.waitUntil(caches.keys().then(keys =>
        Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))
    ));
    self.clients.claim();
});

// Push notification received
self.addEventListener('push', e => {
    const data = e.data ? e.data.json() : {};
    const options = {
        body: data.body || 'Ada notifikasi baru dari MyCloud',
        icon: data.icon || '/icons/icon-192.png',
        badge: data.badge || '/icons/badge-72.png',
        vibrate: [100, 50, 100, 50, 100],
        data: { url: data.url || '/' },
        actions: [
            { action: 'view', title: '👀 Lihat', icon: '/icons/view.png' },
            { action: 'close', title: '✖ Tutup' }
        ],
        requireInteraction: false,
        silent: false
    };

    e.waitUntil(
        self.registration.showNotification(data.title || '🔔 MyCloud', options)
    );
});

// Notification click
self.addEventListener('notificationclick', e => {
    e.notification.close();
    if (e.action === 'close') return;

    const url = e.notification.data?.url || '/pages/tasks.html';
    e.waitUntil(
        clients.matchAll({ type: 'window', includeUncontrolled: true }).then(clientList => {
            for (const client of clientList) {
                if (client.url.includes(self.location.origin) && 'focus' in client) {
                    client.navigate(url);
                    return client.focus();
                }
            }
            return clients.openWindow(url);
        })
    );
});

// Fetch (network first, then cache)
self.addEventListener('fetch', e => {
    if (e.request.method !== 'GET') return;
    if (e.request.url.includes('/api/')) return;

    e.respondWith(
        fetch(e.request).catch(() => caches.match(e.request))
    );
});
